/**
 * optimizer.js
 * Handles performance optimizations for X on mobile web.
 */

console.log('X Mobile Optimizer: Loaded');

// Configuration
const CONFIG = {
    removeAds: true,
    removeSidebar: true,
    optimizeMedia: true,
    debug: false
};

// Selectors
const SELECTORS = {
    // Common ad indicators
    adPlacement: '[data-testid="placementTracking"]',
    // Specific text indicators often found in ads (Promoted, etc)
    promotedLabel: 'span:contains("Promoted")', // Helper needed for :contains

    // Sidebar elements
    sidebarColumn: '[data-testid="sidebarColumn"]',
    trending: '[data-testid="trend"]',
    whoToFollow: '[data-testid="UserCell"]', // Be careful with this one

    // Navigation distractions
    grokButton: '[aria-label="Grok"]',
    verifiedOrg: '[aria-label="Verified Organizations"]',
    premiumEntry: '[aria-label="Premium"]',
};

// Initialize
function initOptimizer() {
    console.log('X Mobile Optimizer: Initializing...');
    // Load settings from storage
    chrome.storage.local.get(['config'], (result) => {
        if (result.config) {
            Object.assign(CONFIG, result.config);
        }
        log('Config loaded:', CONFIG);

        // Initial cleanup
        cleanup();

        // Start observing for new content
        startObservation();
    });
}

function log(...args) {
    if (CONFIG.debug) console.log('XMO:', ...args);
}

// DOM Observer to handle dynamic content
const observer = new MutationObserver((mutations) => {
    let shouldCleanup = false;

    for (const mutation of mutations) {
        if (mutation.addedNodes.length > 0) {
            shouldCleanup = true;
            break;
        }
    }

    if (shouldCleanup) {
        // Debounce potential high-frequency calls if needed, 
        // but for simple hiding, direct call is usually fine.
        requestAnimationFrame(cleanup);
    }
});

function startObservation() {
    const targetNode = document.body;
    if (!targetNode) return;

    const config = { childList: true, subtree: true };
    observer.observe(targetNode, config);
    log('Observer started');
}

function cleanup() {
    if (CONFIG.removeAds) removeAds();
    if (CONFIG.removeSidebar) removeSidebar();
    if (CONFIG.optimizeMedia) optimizeMedia();
}

// --- Optimization Logic ---

function removeAds() {
    // 1. Data-testid based removal
    const ads = document.querySelectorAll(SELECTORS.adPlacement);
    ads.forEach(ad => {
        const tweetCell = ad.closest('[data-testid="cellInnerDiv"]');
        if (tweetCell && tweetCell.dataset.xmoHidden !== 'true') {
            // Use opacity and height management instead of simple display:none
            // to avoid breaking X's virtual scroll calculations
            tweetCell.style.opacity = '0';
            tweetCell.style.pointerEvents = 'none';
            tweetCell.style.height = '0.01px'; // Minimum height to prevent collapse overlap
            tweetCell.dataset.xmoHidden = 'true';
            log('Removed ad safely');
        }
    });
}


function removeSidebar() {
    // On mobile, the sidebar is usually hidden or different.
    // This targets desktop/tablet views mainly.
    const sidebar = document.querySelector(SELECTORS.sidebarColumn);
    if (sidebar && sidebar.style.display !== 'none') {
        sidebar.style.display = 'none';
        log('Hidden Sidebar');
    }

    // Hide extraneous nav items on mobile drawer or bottom bar if accessible
    // Nav items usually have aria-labels
    const unwantedNavs = [SELECTORS.grokButton, SELECTORS.verifiedOrg];
    unwantedNavs.forEach(selector => {
        const el = document.querySelector(selector);
        if (el && el.style.display !== 'none') {
            el.style.display = 'none';
        }
    });
}

function optimizeMedia() {
    // Set content-visibility to auto for off-screen interaction improvements
    // This is a browser-native feature, harmless to apply broadly on big lists
    const timeline = document.querySelector('[aria-label="Timeline: Your Home Timeline"]');
    if (timeline) {
        // Applying to children cells
        // Careful not to break scroll position logic of virtual lists
        // React virtual lists manage DOM mounting, so content-visibility might conflict.
        // Instead, we can force lower quality images if we could intercept network requests,
        // but that requires more permissions.

        // For now, let's just ensure video autoplay is managed effectively if we can access video tags
        const videos = document.querySelectorAll('video');
        videos.forEach(video => {
            // Logic to pause off-screen videos could go here if not native
        });
    }
}

/**
 * PWA Manifest & Favicon Override
 * Overrides X's native manifest to use our custom icons for PWA install.
 * Uses Data URI to ensure maximum compatibility and installability.
 */
async function overridePWAManifest() {
    log('Overriding PWA Manifest & Favicons...');

    // Helper to convert extension resource to Base64
    const getBase64 = async (url) => {
        const response = await fetch(url);
        const blob = await response.blob();
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.readAsDataURL(blob);
        });
    };

    try {
        const icon192 = await getBase64(chrome.runtime.getURL("assets/pwa_icon_192.png"));
        const icon512 = await getBase64(chrome.runtime.getURL("assets/pwa_icon_512.png"));

        const manifestData = {
            "name": "X",
            "short_name": "X",
            "description": "X",
            "start_url": "/home",
            "display": "standalone",
            "orientation": "portrait",
            "background_color": "#000000",
            "theme_color": "#000000",
            "scope": "/",
            "icons": [
                {
                    "src": icon192,
                    "sizes": "192x192",
                    "type": "image/png",
                    "purpose": "any"
                },
                {
                    "src": icon512,
                    "sizes": "512x512",
                    "type": "image/png",
                    "purpose": "any"
                },
                {
                    "src": icon192,
                    "sizes": "192x192",
                    "type": "image/png",
                    "purpose": "maskable"
                },
                {
                    "src": icon512,
                    "sizes": "512x512",
                    "type": "image/png",
                    "purpose": "maskable"
                }
            ]
        };

        const manifestString = JSON.stringify(manifestData);
        const manifestDataURI = `data:application/json;base64,${btoa(unescape(encodeURIComponent(manifestString)))}`;

        // Replace existing manifest
        const existingManifest = document.querySelector('link[rel="manifest"]');
        if (existingManifest) {
            existingManifest.href = manifestDataURI;
        } else {
            const link = document.createElement('link');
            link.rel = 'manifest';
            link.href = manifestDataURI;
            document.head.appendChild(link);
        }

        log('PWA Manifest overridden with Data URI');
    } catch (e) {
        console.error('XMO: Failed to override manifest:', e);
    }

    // 2. Override Favicons
    const favicons = document.querySelectorAll('link[rel*="icon"]');
    favicons.forEach(el => el.remove());

    const mainFavicon = document.createElement('link');
    mainFavicon.rel = 'icon';
    mainFavicon.href = chrome.runtime.getURL("favicon.ico");
    document.head.appendChild(mainFavicon);

    const appleIcon = document.createElement('link');
    appleIcon.rel = 'apple-touch-icon';
    appleIcon.href = chrome.runtime.getURL("assets/icon_128.png");
    document.head.appendChild(appleIcon);
}

// Run
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        initOptimizer();
        overridePWAManifest();
    });
} else {
    initOptimizer();
    overridePWAManifest();
}

